const copierAds = [
  {
    "id": "workspace",
    "label": "사무실 도입형",
    "headline": "새 사무실의 시작, 복합기부터 제대로",
    "body": "새로운 사무실을 준비하고 계신가요? 복사기스토어에서 우리 사무실에 맞는 복합기 정보를 확인해 보세요.",
    "image": "assets/copierstore/workspace.png"
  },
  {
    "id": "compare",
    "label": "제품 비교형",
    "headline": "복합기 선택, 꼼꼼하게 비교하세요",
    "body": "사무실 환경과 필요한 기능에 맞는 복합기를 찾고 계신가요? 복사기스토어에서 제품 정보를 확인해 보세요.",
    "image": "assets/copierstore/compare.png"
  },
  {
    "id": "consult",
    "label": "상담 유도형",
    "headline": "어떤 복합기가 우리 사무실에 맞을까요?",
    "body": "우리 사무실에는 어떤 복합기가 필요할까요? 복사기스토어 홈페이지에서 제품 정보를 확인하고 상담해 보세요.",
    "image": "assets/copierstore/consult.png"
  }
];
