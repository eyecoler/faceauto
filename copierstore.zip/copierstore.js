let selectedAd = copierAds[0];
let savedBodies = {};
try {
 const saved=JSON.parse(localStorage.getItem('copierstore-ads'));
 if(saved){selectedAd=copierAds.find(ad=>ad.id===saved.id)||selectedAd;savedBodies=saved.bodies&&typeof saved.bodies==='object'?saved.bodies:{};}
} catch {}
const byId=id=>document.getElementById(id);
function destination(ad) {
 const url=new URL('https://www.copierstore.co.kr/');
 Object.entries({utm_source:'instagram',utm_medium:'paid_social',utm_campaign:'copierstore_office_20261008',utm_content:ad.id}).forEach(([key,value])=>url.searchParams.set(key,value));
 return url.href;
}
function persistAd(){try{localStorage.setItem('copierstore-ads',JSON.stringify({id:selectedAd.id,bodies:savedBodies}));}catch{}}
function adSettings(){return {status:'draft_not_published',brand:'복사기스토어',platform:'Instagram via Meta',creative_id:selectedAd.id,headline:selectedAd.headline,primary_text:byId('ad-body').value,destination_url:destination(selectedAd),cta:'LEARN_MORE',daily_budget_krw:5000,budget_scope:'all ads combined',image_filename:'copierstore-'+selectedAd.id+'.png',account_connected:false,published:false,service_area:null,duration_days:null};}
function showAd(ad){
 selectedAd=ad;
 byId('ad-title').textContent=ad.headline;
 byId('selected-label').textContent=ad.label;
 byId('ad-body').value=typeof savedBodies[ad.id]==='string'?savedBodies[ad.id]:ad.body;
 byId('ad-url').value=destination(ad);
 for(const id of ['ad-visit','ad-preview-link'])byId(id).href=destination(ad);
 byId('ad-preview').src=ad.image;
 byId('ad-image').href=ad.image;
 byId('ad-image').download='copierstore-'+ad.id+'.png';
 document.querySelectorAll('[data-ad]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.ad===ad.id)));
 byId('ad-status').textContent='사진·문구·홈페이지 주소가 선택한 광고로 설정되었습니다.';
 persistAd();
}
for(const ad of copierAds){
 const button=document.createElement('button');button.className='choice';button.dataset.ad=ad.id;
 const img=document.createElement('img');img.src=ad.image;img.alt=ad.label+' 광고 이미지';
 const label=document.createElement('strong');label.textContent=ad.label;
 button.append(img,label);button.addEventListener('click',()=>showAd(ad));byId('ad-choices').append(button);
}
byId('ad-body').addEventListener('input',()=>{savedBodies[selectedAd.id]=byId('ad-body').value;persistAd();});
byId('ad-copy').addEventListener('click',async()=>{
 const text=byId('ad-body').value+'\n\n'+destination(selectedAd);
 try{await navigator.clipboard.writeText(text);byId('ad-status').textContent='광고 문구와 홈페이지 주소를 복사했습니다.';}
 catch{let box=byId('ad-copy-fallback');if(!box){box=document.createElement('textarea');box.id='ad-copy-fallback';box.setAttribute('aria-label','직접 복사할 광고 문구와 주소');byId('ad-status').after(box);}box.value=text;box.focus();box.select();byId('ad-status').textContent='아래 선택된 내용을 직접 복사해 주세요.';}
});
byId('ad-export').addEventListener('click',()=>{
 const blob=new Blob([JSON.stringify(adSettings(),null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='copierstore-'+selectedAd.id+'-draft.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
showAd(selectedAd);
